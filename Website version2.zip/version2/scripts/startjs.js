 
	var msg="Experience inner peace at work."
	var j=0;
	var speed=100;
	//document.getElementById("msgDisp").innerHTML=msg;
	//$("#switchAbout").css("display","inline");
	$(document).ready(function typeWriter() {
    
	if (j < msg.length) {
		document.getElementById("msgDisp").innerHTML += msg.charAt(j);
	j++;
    
		setTimeout(typeWriter, speed);		
	}
	if(j==msg.length)
	{
		$("#switchAbout").css("display","inline");
	}
	
	});
 
 