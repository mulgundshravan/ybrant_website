 
	var list=["carda","cardb","cardc"];
	var i=0;
	var j = 0;
	var k=0;
	var twv1 = 'Ambitioni dedisse scripsisse iudicaretur. Cras mattis iudicium purus sit amet fermentum. Donec sed odio operae, eu vulputate felis rhoncus. Praeterea iter est quasdam res quas ex communi. At nos hinc posthac, sitientis piros Afros. Petierunt uti sibi concilium totius Galliae in diem certam indicere. Cras mattis iudicium purus sit amet fermentum.';
	var twv2='Ambitioni dedisse scripsisse iudicaretur. Cras mattis iudicium purus sit amet fermentum. Donec sed odio operae, eu vulputate felis rhoncus. Praeterea iter est quasdam res quas ex communi. At nos hinc posthac, sitientis piros Afros. Petierunt uti sibi concilium totius Galliae in diem certam indicere. Cras mattis iudicium purus sit amet fermentum.';
	var twv3='Ambitioni dedisse scripsisse iudicaretur. Cras mattis iudicium purus sit amet fermentum. Donec sed odio operae, eu vulputate felis rhoncus. Praeterea iter est quasdam res quas ex communi. At nos hinc posthac, sitientis piros Afros. Petierunt uti sibi concilium totius Galliae in diem certam indicere. Cras mattis iudicium purus sit amet fermentum.';
	var speed = 10;
	var flag=0;
	var clickedAbout=false;
	var clickedService=false;
	var clickedContact=false;
	var prevPage;
	//$(document).ready(function typeWriter() {
	//
	//if (j < twv1.length) {
	//	document.getElementById("tw1").innerHTML += twv1.charAt(j);
	//	document.getElementById("tw2").innerHTML += twv1.charAt(j);
	//	document.getElementById("tw3").innerHTML += twv1.charAt(j);
	//	
	//	j++;
	//	setTimeout(typeWriter, speed);
	//	//alert(document.getElementById("tw1").innerHTML);
	//}
	//});
	

	
//	$(".i1").hover(function(){	
//console.log("flag=1");
//flag=1;	
//},function()	
//{	
//	console.log("flag=0");	
//	flag=0;
//}
//);	
//console.log("services page flag="+flag);	
	
	//The below piece of code is used for tag line animation
	//$("#reliable").hover(function(){
    //
	//$("#reliable").animate({height:"80px"});
	//$(".reltext").html("one line about Reliable");
	//},function()
	//{
	//$("#reliable").animate({height:"50px"});
	//$(".reltext").html("");
	//});
	//
	//$("#responsive").hover(function(){
    //
	//$("#responsive").animate({height:"80px"});
	//$(".resptext").html("one line about Responsive");
	//},function()
	//{
	//$("#responsive").animate({height:"50px"});
	//$(".resptext").html("");
	//});
	//
	//
	//$("#better").hover(function(){
    //
	//$("#better").animate({height:"80px"});
	//$(".bettext").html("one line about Better");
	//},function()
	//{
	//$("#better").animate({height:"50px"});
	//$(".bettext").html("");
	//});
	
	function changeServices()
		{
			
				//$(".i1").hover(function(){
				//console.log("flag=1");
				//},function()
				//{
				//	console.log("flag=0");
				//}
				//);
				//console.log("services page flag="+flag);
				
				if(i>=list.length-1)
				{
					//$("."+list[i]).css("display","none");
					$("."+list[i]).fadeOut(3000,function(){
					$("."+list[0]).fadeIn(3000);
					//$(".a1").html(desc[0]);
					//$(".a1").css({color:colorList[0]});
					
					i=0;
					})
				}
				else
				{
				//$("."+list[i]).css("display","none");
				$("."+list[i]).fadeOut(3000,function(){
				$("."+list[i+1]).fadeIn(3000);
				//$(".a1").html(desc[i+1]);
				//$(".a1").css({color:colorList[i+1]});
				i=i+1;
				})
				}
			
			
			//console.log("i vaulue="+i);
			
		}
		
		var myVar =	setInterval(changeServices,6000);
		
		
			$(".i1").hover(function(){	
			$(this).stop();
			$(".alert").stop();
			console.log("hover in");
			clearTimeout(myVar);
			},
			function()
			{
				//$(this).fadeIn();
			//$(this).stop().fadeOut("fast");
			//$(".alert").stop().fadeOut("fast");
			myVar =	setInterval(changeServices,6000);
			console.log("hover out");
			}
			
			);
			//,function()	
			//{	
			//	 myVar =	setInterval(changeServices,7000);
			//}
			//);
		
  
  
  
  
  

  
	//$(".nav-link").hover(function(){
	//	
	//	
	//		
	//	$(this).css({"background-color":"#c3e6ff"});
	//	
	//	
	//	},function(){
    //
	//	if(clickedAbout==true)
	//	{
	//		//console.log("clicked about");
	//		$("#switchAbout").css({"background-color":"#c3e6ff"});
	//		$("#switchService").css({"background-color":"yellow"});
	//		$("#getContact").css({"background-color":"yellow"});
	//		
	//	}
	//	else if(clickedService==true)
	//	{
	//		//console.log("clicked about");
	//		$("#switchService").css({"background-color":"#c3e6ff"});
	//		$("#switchAbout").css({"background-color":"yellow"});
	//		$("#getContact").css({"background-color":"yellow"});
	//	}
	//	else if(clickedContact==true)
	//	{
	//		$("#getContact").css({"background-color":"#c3e6ff"});
	//		$("#switchAbout").css({"background-color":"yellow"});
	//		$("#switchService").css({"background-color":"yellow"});
	//	}
	//	
	//	else
	//	{
	//		$(this).css({"background-color":"yellow"});
	//	}
	//}
	//
	//
	//);
	
//	$('.modal').on('hidden.bs.modal', function () {
//	clickedContact=false;
//	$("#getContact").css({"background-color":"yellow"});
//	if(prevPage=="switchAbout")
//	{
//		$("#"+prevPage).css({"background-color":"#c3e6ff"});
//	}
//	else if (prevPage=="switchService")
//	{
//		$("#"+prevPage).css({"background-color":"#c3e6ff"});
//	}
//	else if(prevPage==null)
//	{
//		$("#switchAbout").css({"background-color":"#c3e6ff"});
//	}
//	//$(this).css({"background-color":"#D8D8D8"});
//
//});
	
	
	$('#getContact').click(function(){
	if(clickedAbout)
	{
		prevPage="switchAbout";
	}
	if(clickedService)
	{
		prevPage="switchService";
	}
	//clickedContact=true;
	//clickedAbout=false;
	//clickedService=false;
	
	$("#exampleModal").modal('show');
	});
	
	
	
  	$("#switchService").click(function ()
			{
				//$('body').load( url,[data],[callback] );
				//alert("test");
				//$(".changerAbout").fadeOut(2000,function(){
				//alert($("div.changerAbout:visible").prop("id"));
				//clickedAbout=false;
				//clickedService=true;
				//clickedContact=false;
				$("#"+$("div.changer:visible").prop("id")).fadeOut(2000,function(){
				$("#2").fadeIn(2000);
				//$("#switchService").css({"background-color":"#c3e6ff"});
				//$("#switchAbout").css({"background-color":"yellow"}); //on hover out change the color
				
				})
				
			});
		$("#switchAbout").click(function ()
			{
				
				//clickedAbout=true;
				//clickedService=false;
				//clickedContact=false;
				//typeWriter();
				$("#"+$("div.changer:visible").prop("id")).fadeOut(2000,function(){
				//$("#"+$("div.changerAbout:visible").prop("id")).css({"display":"none"});
				$("#1").fadeIn(2000);
				//$("#switchAbout").css({"background-color":"#c3e6ff"});
				//$("#switchService").css({"background-color":"yellow"});
				console.log($("#switchAbout").prop("id"));
				//prop( "disabled", true );
				
				})
				
			});	
			
			
			
			
  